//
//  Constant.swift
//  Multiple Collections
//
//  Created by IPH Technologies on 21/04/22.
//  Copyright © 2022 IPH Technologies All rights reserved.

import Foundation

let categoriesWidth = 120
let dataCellHeight = 200

let categoriesHeight = 200
let dataCellWidth = 180

let categoriesCellCornerRadius = 10
let dataCellCornerRadius = 10
