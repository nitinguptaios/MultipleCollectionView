# MutipleCollections
Manage multiple collections views in same screens
Used Json file into App to get movies list.
On Tap Movies used Demo links to play video.
The App is in MVC pattern.
